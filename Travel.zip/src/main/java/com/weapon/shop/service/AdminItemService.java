package com.weapon.shop.service;

import com.weapon.shop.dto.AdminItemDto;
import com.weapon.shop.entity.AdminItemEntity;
import com.weapon.shop.entity.LocalEntity;
import com.weapon.shop.repository.AdminItemRepository;
import com.weapon.shop.repository.LocalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
public class AdminItemService {
    private final AdminItemRepository adminItemRepository;
    @Autowired
    public AdminItemService(AdminItemRepository adminItemRepository) {
        this.adminItemRepository = adminItemRepository;
    }

    @Transactional
    public void saveAdminItem(AdminItemDto adminItemDto) {
        // AdminItemDto를 AdminItemEntity로 변환
        AdminItemEntity adminItemEntity = convertToEntity(adminItemDto);

        // AdminItemEntity를 저장
        adminItemRepository.save(adminItemEntity);
    }

    private AdminItemEntity convertToEntity(AdminItemDto adminItemDto) {
        AdminItemEntity adminItemEntity = new AdminItemEntity();
        adminItemEntity.setImgUrl(adminItemDto.getImgUrl()); // 이미지 URL 설정
        adminItemEntity.setTouristSpotName(adminItemDto.getTouristSpotName());
        adminItemEntity.setAddress(adminItemDto.getAddress());
        adminItemEntity.setContact(adminItemDto.getContact());
        adminItemEntity.setFeatures(adminItemDto.getFeatures());
        adminItemEntity.setBusinessHours(adminItemDto.getBusinessHours());
        // 필요한 다른 필드들도 설정

        return adminItemEntity;
    }



}
