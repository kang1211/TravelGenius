package com.weapon.shop.service;

import com.weapon.shop.dto.SchedulerDto;
import com.weapon.shop.entity.Scheduler;
import com.weapon.shop.repository.SchedulerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;

@Service
@Transactional
@RequiredArgsConstructor
public class SchedulerService {

    private final SchedulerRepository schedulerRepository;

    public void saveScheduler(SchedulerDto schedulerDto) {
        Scheduler scheduler = Scheduler.createScheduler(schedulerDto);
        schedulerRepository.save(scheduler);
    }
}
