package com.weapon.shop.constant;

public enum Role {
    USER, ADMIN
}
