package com.weapon.shop.entity;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QAdminItemEntity is a Querydsl query type for AdminItemEntity
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QAdminItemEntity extends EntityPathBase<AdminItemEntity> {

    private static final long serialVersionUID = -1040476659L;

    public static final QAdminItemEntity adminItemEntity = new QAdminItemEntity("adminItemEntity");

    public final StringPath address = createString("address");

    public final MapPath<String, String, StringPath> businessHours = this.<String, String, StringPath>createMap("businessHours", String.class, String.class, StringPath.class);

    public final StringPath contact = createString("contact");

    public final StringPath features = createString("features");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final StringPath imgUrl = createString("imgUrl");

    public final StringPath touristSpotName = createString("touristSpotName");

    public QAdminItemEntity(String variable) {
        super(AdminItemEntity.class, forVariable(variable));
    }

    public QAdminItemEntity(Path<? extends AdminItemEntity> path) {
        super(path.getType(), path.getMetadata());
    }

    public QAdminItemEntity(PathMetadata metadata) {
        super(AdminItemEntity.class, metadata);
    }

}

